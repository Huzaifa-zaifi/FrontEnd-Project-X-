import axios from "axios";

const API_URL = "http://localhost:5001/api/supervisor"; // adjust if your backend runs on another port

// Add your token here if you use JWT authentication
const token = localStorage.getItem("token");

const config = {
  headers: {
    Authorization: `Bearer ${token}`,
  },
};

// Fetch dashboard stats
export const getDashboardStats = async () => {
  const res = await axios.get(`${API_URL}/dashboard`, config);
  return res.data;
};

// Fetch submitted observations
export const getSubmittedObservations = async () => {
  const res = await axios.get(`${API_URL}/observations/submitted`, config);
  return res.data;
};

// Review observation
export const reviewObservation = async (id, action, comment) => {
  const res = await axios.patch(`${API_URL}/observations/${id}/review`, { action, comment }, config);
  return res.data;
};

// Fetch analytics
export const getAnalytics = async () => {
  const res = await axios.get(`${API_URL}/analytics`, config);
  return res.data;
};

// Existing functions
export const getAllObservationsForTracking = async () => {
    try {
      const response = await axios.get("/api/supervisor/observations/all");
      return response.data;
    } catch (err) {
      console.error(err);
      throw err;
    }
  };
  
