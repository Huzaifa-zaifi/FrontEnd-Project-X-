import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Search,
  User,
  Clock,
  Calendar,
  AlertCircle,
  Image as ImageIcon,
  CheckCircle,
  XCircle,
} from "lucide-react";
import SupervisorSidebar from "./SupervisorSidebar";

const API_URL = "http://localhost:5001/api/supervisor";

export default function SupervisorObservations() {
  const [observations, setObservations] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchObservations = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get(`${API_URL}/observations/submitted`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setObservations(res.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchObservations();
  }, []);

  const handleAction = async (id, action) => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.patch(
        `${API_URL}/observations/${id}/review`,
        { action },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Remove the observation from current list if its status changed
      setObservations((prev) =>
        prev.filter((obs) => obs._id !== res.data._id)
      );

      // Optionally show toast / success message
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="p-8">Loading...</div>;

  return (
    <div className="flex min-h-screen bg-gray-50">
      <SupervisorSidebar />

      <main className="flex-1 p-8">
        {/* HEADER */}
        <div className="flex justify-between items-center mb-10 animate-fade-in">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">New Observations</h2>
            <p className="text-gray-600 mt-1">
              Review submitted observations and take action
            </p>
          </div>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search observations..."
              className="pl-12 pr-6 py-3.5 w-80 rounded-xl border border-gray-200 shadow-sm focus:ring-4 focus:ring-red-100 focus:border-red-500"
            />
          </div>
        </div>

        {/* OBSERVATIONS LIST */}
        <div className="space-y-8">
          {observations.map((obs, index) => (
            <div
              key={obs._id}
              style={{ animationDelay: `${index * 120}ms` }}
              className="bg-white rounded-3xl border border-red-100 shadow-xl overflow-hidden animate-slide-up transition-all duration-300 hover:shadow-2xl hover:-translate-y-1"
            >
              <div className="flex flex-col lg:flex-row">
                {/* IMAGE */}
                {obs.imageUrl && (
                  <div className="lg:w-96 bg-gradient-to-br from-red-50 to-white p-6 border-r border-red-100">
                    <div className="h-64 rounded-2xl border-2 border-dashed border-red-200 flex flex-col items-center justify-center text-red-400">
                      <ImageIcon size={32} />
                      <span className="mt-2 font-semibold">Photo Attached</span>
                    </div>
                  </div>
                )}

                {/* CONTENT */}
                <div className={`flex-1 p-8 ${!obs.imageUrl ? "lg:px-16" : ""}`}>
                  <div className="flex justify-between gap-6 mb-6">
                    <div>
                      <h3 className="text-2xl font-extrabold text-gray-900">
                        {obs.description}
                      </h3>
                      <div className="flex flex-wrap gap-5 mt-3 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <User size={16} /> {obs.employee?.name || "Unknown"}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock size={16} /> {new Date(obs.createdAt).toLocaleDateString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar size={16} /> {obs.category}
                        </span>
                      </div>
                    </div>
                    <span className="px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-2 bg-red-100 text-red-600">
                      <AlertCircle size={16} /> {obs.type}
                    </span>
                  </div>

                  {/* ACTION BUTTONS */}
                  <div className="flex flex-col sm:flex-row gap-5">
                    <button
                      onClick={() => handleAction(obs._id, "IN_REVIEW")}
                      className="relative overflow-hidden flex-1 group rounded-2xl bg-gradient-to-r from-yellow-500 to-yellow-600 px-6 py-4 text-white text-lg font-bold shadow-xl transition-all hover:scale-[1.03]"
                    >
                      Mark In Review
                    </button>
                    <button
                      onClick={() => handleAction(obs._id, "CLOSE")}
                      className="relative overflow-hidden flex-1 group rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-6 py-4 text-white text-lg font-bold shadow-xl transition-all hover:scale-[1.03]"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleAction(obs._id, "REJECT")}
                      className="flex items-center justify-center gap-2 px-10 py-4 rounded-2xl border border-gray-300 text-gray-600 font-semibold hover:bg-gray-100 hover:shadow transition"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {observations.length === 0 && (
            <p className="text-center text-gray-500">No new observations</p>
          )}
        </div>
      </main>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
        .animate-slide-up {
          animation: slideUp 0.7s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
