import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Components/Login';
import Dashboard from './Components/Dashboard';
import SubmitReport from './Components/SubmitReport';
import ReportStatusPage from './Components/Status';
import HistoryPage from './Components/History';
import ObservationDetails from './Components/ObservationDetails';
import SupervisorDashboard from './Components/Supervisor/Supd';
import ApproveRejectObservations from './Components/Supervisor/Approve';
import AssignCorrectiveActions from './Components/Supervisor/Assign';
import TrackProgressOfActions from './Components/Supervisor/Track';
import SupervisorObservations from './Components/Supervisor/ViewNewObservations';

function App() {
  return (
    <Router>
      <Routes>
        {/* Login Page */}
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />

        {/* Other Pages */}
        <Route path="/EMP-dashboard" element={<Dashboard />} />
        <Route path="/submit" element={<SubmitReport />} />
        <Route path="/status" element={<ReportStatusPage />} />
        <Route path="/history" element={<HistoryPage />} />
        <Route path="/observations/:id" element={<ObservationDetails />} />

        {/* Supervisor */}
        <Route path="/supervisor-dashboard" element={<SupervisorDashboard />} />
        <Route path="/approve-reject" element={<ApproveRejectObservations />} />
        <Route path="/assign-act" element={<AssignCorrectiveActions />} />
        <Route path="/track" element={<TrackProgressOfActions />} />
        <Route path="/view-observations" element={<SupervisorObservations />} />



        {/* Catch-all redirect to login */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
